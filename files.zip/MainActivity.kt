package com.example.prompter

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import android.app.Activity

class MainActivity : Activity() {

    private lateinit var etScript: EditText
    private lateinit var sbSpeed: SeekBar
    private lateinit var sbSize: SeekBar
    private lateinit var tvSpeed: TextView
    private lateinit var tvSize: TextView

    private val prefs by lazy { getSharedPreferences("prompter", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContentView(buildUi())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        col.addView(TextView(this).apply {
            text = "Prompter Kamera"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        etScript = EditText(this).apply {
            hint = "Tempel atau ketik naskah di sini…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 8
            gravity = Gravity.TOP
            setText(prefs.getString("script", ""))
        }
        col.addView(etScript, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        tvSpeed = TextView(this)
        sbSpeed = SeekBar(this).apply {
            max = 290 // 10..300 px/detik
            progress = prefs.getInt("speed", 60) - 10
        }
        tvSize = TextView(this)
        sbSize = SeekBar(this).apply {
            max = 32 // 16..48 sp
            progress = prefs.getInt("size", 26) - 16
        }
        fun refreshLabels() {
            tvSpeed.text = "Kecepatan gulir: ${sbSpeed.progress + 10} px/detik"
            tvSize.text = "Ukuran teks: ${sbSize.progress + 16} sp"
        }
        val watcher = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = refreshLabels()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        sbSpeed.setOnSeekBarChangeListener(watcher)
        sbSize.setOnSeekBarChangeListener(watcher)
        refreshLabels()

        col.addView(tvSpeed, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        col.addView(sbSpeed)
        col.addView(tvSize, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(sbSize)

        col.addView(Button(this).apply {
            text = "Mulai Prompter Mengambang"
            setOnClickListener { startPrompter() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })

        col.addView(Button(this).apply {
            text = "Hentikan Prompter"
            setOnClickListener { stopService(Intent(this@MainActivity, PrompterService::class.java)) }
        })

        col.addView(TextView(this).apply {
            text = "Cara pakai: tekan Mulai → buka aplikasi Kamera bawaan. " +
                "Kotak prompter akan melayang di atas kamera. Geser lewat bilah atas, " +
                "ubah ukuran lewat pojok kanan bawah (◢)."
            textSize = 13f
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        return ScrollView(this).apply { addView(col) }
    }

    private fun startPrompter() {
        // 1. Izin "Tampil di atas aplikasi lain"
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin 'Tampil di atas aplikasi lain'", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }

        val script = etScript.text.toString().ifBlank { "Naskah kosong. Ketik naskah di aplikasi dulu." }
        val speed = sbSpeed.progress + 10
        val size = sbSize.progress + 16
        prefs.edit().putString("script", etScript.text.toString())
            .putInt("speed", speed).putInt("size", size).apply()

        val i = Intent(this, PrompterService::class.java).apply {
            putExtra("script", script)
            putExtra("speed", speed.toFloat())
            putExtra("size", size.toFloat())
        }
        startForegroundService(i)

        // 2. Buka aplikasi kamera bawaan otomatis
        try {
            startActivity(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        } catch (e: Exception) {
            Toast.makeText(this, "Buka aplikasi Kamera secara manual", Toast.LENGTH_SHORT).show()
        }
    }
}
