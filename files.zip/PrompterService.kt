package com.example.prompter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class PrompterService : Service() {

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var scroll: ScrollView
    private lateinit var tvText: TextView
    private lateinit var btnPlay: Button

    private val handler = Handler(Looper.getMainLooper())
    private var playing = false
    private var speed = 60f          // px per detik
    private var textSp = 26f
    private var accum = 0f
    private var lastTick = 0L

    private val ticker = object : Runnable {
        override fun run() {
            if (!playing) return
            val now = SystemClock.uptimeMillis()
            accum += speed * ((now - lastTick) / 1000f)
            lastTick = now
            val step = accum.toInt()
            if (step > 0) {
                scroll.scrollBy(0, step)
                accum -= step
            }
            if (!scroll.canScrollVertically(1)) { // sudah sampai akhir
                setPlaying(false)
                return
            }
            handler.postDelayed(this, 16)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val script = intent?.getStringExtra("script") ?: ""
        speed = intent?.getFloatExtra("speed", 60f) ?: 60f
        textSp = intent?.getFloatExtra("size", 26f) ?: 26f

        if (root == null) buildOverlay(script)
        else { tvText.text = script; tvText.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp) }
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.TRANSPARENT)
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(dp(10), dp(4), dp(10), dp(4))
        setOnClickListener { onClick() }
    }

    private fun buildOverlay(script: String) {
        val screenW = resources.displayMetrics.widthPixels

        params = WindowManager.LayoutParams(
            (screenW * 0.9f).toInt(),
            dp(240),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_FOCUSABLE + NOT_TOUCH_MODAL: sentuhan di luar kotak tetap
            // diteruskan ke aplikasi kamera di bawahnya.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW * 0.05f).toInt()
            y = dp(80)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(170, 0, 0, 0)) // hitam semi-transparan
        }

        // ---------- Bilah atas: drag + kontrol ----------
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(200, 40, 40, 40))
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        val handle = TextView(this).apply {
            text = "☰"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(8), 0, dp(12), 0)
        }
        btnPlay = smallButton("▶") { setPlaying(!playing) }

        bar.addView(handle)
        bar.addView(btnPlay)
        bar.addView(smallButton("⟲") { scroll.scrollTo(0, 0); accum = 0f })
        bar.addView(smallButton("−") { speed = (speed - 10f).coerceAtLeast(10f) })
        bar.addView(smallButton("+") { speed = (speed + 10f).coerceAtMost(300f) })
        bar.addView(smallButton("A-") { changeTextSize(-2f) })
        bar.addView(smallButton("A+") { changeTextSize(+2f) })
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) // spacer
        bar.addView(smallButton("✕") { stopSelf() })

        // geser jendela dengan menyeret bilah atas
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(container, params)
                }
            }
            true
        }

        // ---------- Area teks ----------
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        tvText = TextView(this).apply {
            text = script
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
            setLineSpacing(0f, 1.2f)
            // padding atas/bawah agar teks mulai dari bawah & bisa tergulir habis
            setPadding(dp(14), dp(100), dp(14), dp(140))
        }
        scroll.addView(tvText)

        // ---------- Pegangan resize (pojok kanan bawah) ----------
        val resize = TextView(this).apply {
            text = "◢"
            setTextColor(Color.WHITE)
            gravity = Gravity.END
            setPadding(0, 0, dp(8), dp(2))
        }
        var startW = 0; var startH = 0
        resize.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startW = params.width; startH = params.height
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.width = (startW + (e.rawX - touchX)).toInt().coerceAtLeast(dp(160))
                    params.height = (startH + (e.rawY - touchY)).toInt().coerceAtLeast(dp(120))
                    wm.updateViewLayout(container, params)
                }
            }
            true
        }

        container.addView(bar, LinearLayout.LayoutParams(-1, -2))
        container.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        container.addView(resize, LinearLayout.LayoutParams(-1, -2))

        root = container
        wm.addView(container, params)
    }

    private fun changeTextSize(delta: Float) {
        textSp = (textSp + delta).coerceIn(14f, 60f)
        tvText.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
    }

    private fun setPlaying(p: Boolean) {
        playing = p
        btnPlay.text = if (p) "⏸" else "▶"
        if (p) {
            lastTick = SystemClock.uptimeMillis()
            handler.post(ticker)
        } else {
            handler.removeCallbacks(ticker)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "prompter"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Prompter", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("Prompter aktif")
            .setContentText("Ketuk untuk membuka pengaturan")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
}
